package Dao.Activity;

/**
 * @description: 活动申请表
 * @author: 十月
 * @create: 2021-01-06 13:49
 **/
public class activityApplyBean {

}
